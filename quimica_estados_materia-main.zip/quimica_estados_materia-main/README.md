# quimica_estados_materia
Estados de la materia 
# 🌟 Estados de la Materia — Juega y Aprende

Actividad interactiva web (HTML+CSS+JS puro) para enseñar **sólido, líquido y gaseoso** con una **llama** que derrite y evapora, **narración por voz**, **sonidos** y **modo automático**.

## 🚀 Demo local
1. Clona el repo:
   ```bash
   git clone https://github.com/<TU_USUARIO>/estados-materia.git
   cd estados-materia
